package mk.ukim.finki.lab.repository.inmemory;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import mk.ukim.finki.lab.model.Album;

@Service
public class InMemoryAlbumRepository {
    private final List<Album> albums;

    public InMemoryAlbumRepository() {
        this.albums = List.of(
                new Album("Hit me hard and soft", "R&B", "2024"),
                new Album("Girls", "Pop", "2023"),
                new Album("Rosie", "Pop", "2024"),
                new Album("Dynasty", "Rock", "2020"),
                new Album("Two of Us", "Jazz", "2014"));
    }

    public List<Album> findAll() {
        return albums;
    }

    public Optional<Album> findById(Long id) {
        return albums.stream().filter(album -> album.getId().equals(id)).findAny();
    }

}
