package mk.ukim.finki.lab.repository.inmemory;

import org.springframework.stereotype.Repository;

import mk.ukim.finki.lab.model.Album;
import mk.ukim.finki.lab.model.Artist;
import mk.ukim.finki.lab.model.Song;
import mk.ukim.finki.lab.service.AlbumService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Repository
public class InMemorySongRepository {
    private final List<Song> songs;
    private final AlbumService albums;

    public InMemorySongRepository(AlbumService albums) {
        this.albums = albums;
        this.songs = new ArrayList<>(Arrays.asList(
                new Song("Lunch", "R&B", 2024, this.albums.findById(1)),
                new Song("Girls Go Wild", "Pop", 2023, this.albums.findById(2)),
                new Song("APT", "Pop", 2024, this.albums.findById(3)),
                new Song("I Was Made For Lovin You", "Rock", 2020, this.albums.findById(4)),
                new Song("Just Two of Us", "Jazz", 2014, this.albums.findById(5))));
    }

    public List<Song> findAll() {
        return songs;
    }

    public Optional<Song> findByTrackId(Long trackId) {
        return songs.stream().filter(s -> s.getId().equals(trackId)).findFirst();
        //return null;
    }

    public Artist addArtistToSong(Artist artist, Song song) {
        song.getPerformers().add(artist);
        return artist;
    }

    public Optional<Song> save(Song song) {

        if (this.songs.stream().anyMatch(e -> e.getId().equals(song.getId()))) {
            return Optional.of(song);
        }

        this.songs.add(song);
        return Optional.of(song);
    }

//    public Song updateSong(Long id, String title, String genre, Integer releaseDate, Album album) {
//
//        Song toUpdate = this.songs
//                .stream()
//                .filter(e -> e.getId().equals(id))
//                .findAny()
//                .orElse(null);
//
//        if (toUpdate != null) {
//            toUpdate.setTitle(title);
//            toUpdate.setGenre(genre);
//            toUpdate.setReleaseYear(releaseDate);
//            toUpdate.setAlbum(album);
//        }
//
//        return toUpdate;
//    }
    public Album findAlbumById(Long albumId) {
       return albums.findById(albumId);
    }

    public boolean removeSong(Long id) {

        Optional<Song> toDelete = this.songs
                .stream()
                .filter(event -> event.getId().equals(id))
                .findAny();

        return toDelete.isPresent() && this.songs.remove(toDelete.get());
    }
}