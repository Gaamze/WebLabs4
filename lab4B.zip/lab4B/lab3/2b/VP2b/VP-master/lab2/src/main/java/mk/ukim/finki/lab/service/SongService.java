package mk.ukim.finki.lab.service;

import java.util.List;
import java.util.Optional;

import mk.ukim.finki.lab.model.Album;
import mk.ukim.finki.lab.model.Artist;
import mk.ukim.finki.lab.model.Song;


public interface SongService {

    List<Song> listSongs();

    Song addArtistToSong(Long artistId, Long songId);

    Optional<Song> findByTrackId(Long trackId);

    Optional<Song> update(Long id, String title, String genre, Integer releaseYear, Album album);

    Optional<Song> saveSong(String title, String genre, Integer releaseYear, Album album);

    void removeSong(Long id);
}
