package mk.ukim.finki.lab.repository.inmemory;

import org.springframework.stereotype.Repository;

import mk.ukim.finki.lab.model.Artist;

import java.util.List;
import java.util.Optional;

@Repository
public class InMemoryArtistRepository {
    private final List<Artist> artists;

    public InMemoryArtistRepository() {
        this.artists = List.of(
                new Artist("Billie", "Eilish", "Singer"),
                new Artist("Lp", "Lp", "Singer"),
                new Artist("Bruno", "Mars", "Singer-Actor"),
                new Artist("Kiss", "Kiss", "Group "),
                new Artist("Grover", "Washington", "Song writer"));
    }

    public List<Artist> findAll() {
        return artists;
    }

    public Optional<Artist> findById(Long id) {
        for (Artist artist : artists) {
            if (artist.getId().equals(id)) {
                return Optional.of(artist);
            }
        }
        return Optional.empty();
    }

}
