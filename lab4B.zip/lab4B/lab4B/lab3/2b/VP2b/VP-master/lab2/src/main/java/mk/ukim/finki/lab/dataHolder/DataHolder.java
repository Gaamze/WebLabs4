package mk.ukim.finki.lab.dataHolder;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.lab.model.Album;
import mk.ukim.finki.lab.model.Artist;
import mk.ukim.finki.lab.model.Song;
import mk.ukim.finki.lab.repository.jpa.AlbumRepository;
import mk.ukim.finki.lab.repository.jpa.ArtistRepository;
import mk.ukim.finki.lab.repository.jpa.SongRepository;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class DataHolder {

    private final AlbumRepository albumRepository;
    private final SongRepository songRepository;
    private final ArtistRepository artistRepository;

    public DataHolder(AlbumRepository albumRepository, SongRepository songRepository, ArtistRepository artistRepository) {
        this.albumRepository = albumRepository;
        this.songRepository = songRepository;
        this.artistRepository = artistRepository;
    }

    @PostConstruct
    public void init() {

        Artist artist1 = new Artist("Billie", "Billie", "Group");
        Artist artist2 = new Artist("Lp", "Lp", "Singer");
        Artist artist3 = new Artist("Bruno", "Mars", "Singer-Actor");
        Artist artist4 = new Artist("Kiss", "Kiss", "Singer");
        Artist artist5 = new Artist("Grover", "Washington", "Song writer");

        artistRepository.saveAll(Arrays.asList(artist1, artist2, artist3, artist4,artist5));

        Album album1 = new Album("Hit me hard and soft", "R&B", "2024");
        Album album2 = new Album("Girls", "Pop", "2023");
        Album album3= new Album("Rosie", "Pop", "2024");
        Album album4=new Album("Dynasty", "Rock", "2020");
        Album album5=new Album("Two of Us", "Jazz", "2014");

        albumRepository.saveAll(Arrays.asList(album1, album2, album3, album4, album5));

        Song song1 =   new Song("Lunch", "R&B", 2024,album1);
        Song song2 =   new Song("Girls Go Wild", "Pop", 2023, album2);
        Song song3 =   new Song("APT", "Pop", 2024, album3);
        Song song4=    new Song("I Was Made For Lovin You", "Rock", 2020, album4);
        Song song5=    new Song("Just Two of Us", "Jazz", 2014, album5);

        // Assign performers to songs
        song1.addPerformer(artist1);
        song2.addPerformer(artist2);
        song3.addPerformer(artist3);
        song4.addPerformer(artist4);
        song5.addPerformer(artist5);

        // Save songs to the repository
        songRepository.saveAll(Arrays.asList(song1, song2, song3, song4, song5));

        // Assign songs to albums
        album1.setSongs(Arrays.asList(song1));
        album2.setSongs(Arrays.asList(song2));
        album3.setSongs(Arrays.asList(song3));
        album4.setSongs(Arrays.asList(song4));
        album5.setSongs(Arrays.asList(song5));
        albumRepository.save(album1);
        albumRepository.save(album2);
        albumRepository.save(album3);
        albumRepository.save(album4);
        albumRepository.save(album5);
    }
}
