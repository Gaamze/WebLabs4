package mk.ukim.finki.lab.service;

import java.util.List;
import java.util.Optional;

import jakarta.transaction.Transactional;
import mk.ukim.finki.lab.repository.jpa.ArtistRepository;
import org.springframework.stereotype.Service;

import mk.ukim.finki.lab.model.Album;
import mk.ukim.finki.lab.model.Artist;
import mk.ukim.finki.lab.model.Song;
//import mk.ukim.finki.lab.repository.inmemory.InMemoryArtistRepository;
//import mk.ukim.finki.lab.repository.inmemory.InMemorySongRepository;
import mk.ukim.finki.lab.repository.jpa.SongRepository;

@Service
public class SongServiceImpl implements SongService {
    private final SongRepository songRepository;
    private final ArtistRepository artistRepository;

    public SongServiceImpl(SongRepository songRepository, ArtistRepository artistRepository) {
        this.songRepository = songRepository;
        this.artistRepository = artistRepository;
    }

    @Override
    public List<Song> listSongs() {
        return songRepository.findAll();
    }

    @Override
    @Transactional
    public Song addArtistToSong(Long artistId, Long songId) {

        Artist a = this.artistRepository.findById(artistId).orElse(null);
        Song s = this.songRepository.findById(songId).orElse(null);

        if(s != null && a != null) {
            s.getPerformers().add(a);
            songRepository.save(s);
        }

        return s;
    }

    @Override
    public Optional<Song> findByTrackId(Long trackId) {
        return songRepository.findById(trackId);
    }

    @Override
    public Optional<Song> saveSong(String title, String genre, Integer releaseYear, Album album) {
        return Optional.of(songRepository.save(new Song(title, genre, releaseYear, album)));
//        return Optional.of(new Song());
    }


    @Override
    public void removeSong(Long id) {

        songRepository.deleteById(id);
    }

    @Override
    public Optional<Song> update(Long id, String title, String genre, Integer releaseYear, Album album) {
        Song s = songRepository.findById(id).orElse(null);
        s.setTitle(title);
        s.setGenre(genre);
        s.setReleaseYear(releaseYear);
        s.setAlbum(album);
        return Optional.of(songRepository.save(s));
    }

}
