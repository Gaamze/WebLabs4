package mk.ukim.finki.lab.repository.jpa;

import mk.ukim.finki.lab.model.Album;
import mk.ukim.finki.lab.model.Artist;
import mk.ukim.finki.lab.model.Song;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SongRepository extends JpaRepository <Song, Long> {
    List<Song> findAllByAlbum_Id(Long albumId);

    //Song updateSong(Long id, String title, String genre, Integer releaseYear, Album album);
//    Artist addArtistToSong(Artist artist, Song song);

//    Song updateSong(Long id, String title, String genre, Integer releaseYear, Album album);
}
