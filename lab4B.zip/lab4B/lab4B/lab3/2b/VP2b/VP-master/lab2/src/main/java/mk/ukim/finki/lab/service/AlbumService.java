package mk.ukim.finki.lab.service;

import java.util.List;

import mk.ukim.finki.lab.model.Album;

public interface AlbumService {
    List<Album> findAll();
    Album findById(long id);
}
